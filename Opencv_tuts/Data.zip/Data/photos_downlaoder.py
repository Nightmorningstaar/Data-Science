from bing_image_downloader import downloader

query_string = 'Tom Sturridge'  # Replace 'actor name' with the actual name of the actor you want to download images of
limit = 50  # Change the limit to download more or less images
output_directory = 'downloaded_images'  # The directory where downloaded images will be saved

downloader.download(query_string, limit=limit, output_dir=output_directory, adult_filter_off=True, force_replace=False, timeout=60)