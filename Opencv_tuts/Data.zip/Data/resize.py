import cv2
import os

output_directory = r'Data\train_images\Tom Sturridge'


for filename in os.listdir(output_directory):
    image_path = os.path.join(output_directory, filename)
    # Load the image from disk
    image = cv2.imread(image_path)
    # Resize the image to 50% of its original size
    resized_image = cv2.resize(image, (0, 0), fx=0.5, fy=0.5)
    # Save the resized image to disk
    cv2.imwrite(image_path, resized_image)